# Statistics and figure rule

## Statistical review

For every analysis, verify where applicable:

- unique biological unit and independence;
- inclusion/exclusion criteria;
- missingness handling;
- preprocessing and transformation;
- prespecified versus exploratory status;
- model formula and covariates;
- effect-size definition;
- confidence interval method;
- test sidedness;
- multiplicity correction;
- proportional-hazards assumptions;
- calibration and discrimination where a model is claimed;
- internal resampling leakage;
- external-cohort independence;
- sensitivity analyses and negative controls.

Do not demand analyses merely because they are conventional. Distinguish fatal validity issues from desirable additions.

## Figures

- Every panel must have one sentence stating the scientific job it performs.
- Remove decorative panels that do not advance the causal or clinical argument.
- Do not place a result in the main figure if it cannot be sourced and reproduced.
- Panel letters, labels, group names, n, and statistics must match legend and manuscript.
- Show uncertainty and raw distributions where scientifically appropriate.
- Use colorblind-safe palettes and retain meaning in grayscale.
- Do not use bar charts for distributions when dot/box/violin plots are feasible.
- Forest plots must display effect definition, reference direction, confidence intervals, and model.
- Survival plots must show numbers at risk and define censoring.
- Correlation plots must show n, method, rho/r, p-value, and biological unit.
- Heatmaps must state scaling, clustering, missing-value handling, and annotation definitions.
