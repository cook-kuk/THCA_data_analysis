# File and execution safety rule

- Do not delete or overwrite raw data, downloaded datasets, original figures, or prior manuscript versions.
- Write new review artifacts under `manuscript_v8/review_runs/<timestamp>/`.
- Write repaired manuscript candidates with a new date/version until the author approves promotion to canonical status.
- Do not execute commands that publish, upload, push, release, email, or alter remote resources without explicit authorization.
- Do not expose credentials, access tokens, patient-level restricted data, or private local paths in manuscript files.
- Prefer deterministic scripts and record commands, package versions, and random seeds.
- If a command fails, report the failure and preserve logs. Do not fabricate the expected output.
