# Evidence lock rule

Applies to all manuscript, caption, cover-letter, reviewer-response, and submission files.

- Never create a claim from narrative notes alone when a primary output should exist.
- For each quantitative claim, capture: claim ID, exact wording, endpoint, cohort, n, effect, interval, p-value, model, covariates, reference, source file, source line/table, and verification status.
- Do not round differently across abstract, Results, captions, tables, and supplement.
- Preserve exact versus approximate values. Replace “approximately” with an exact value only after source verification.
- A p-value is incomplete without a named test, comparison, and sidedness.
- A hazard ratio is incomplete without event, time origin, unit/contrast, and reference group.
- A correlation is incomplete without unit of independence and method.
- A cohort count is incomplete without defining the counting unit.
- A non-significant test cannot establish equivalence or missing-at-random status.
- If a source file cannot be found, mark the claim `UNVERIFIED` and keep it out of the final abstract and cover letter.
- Never optimize wording to conceal uncertainty.
