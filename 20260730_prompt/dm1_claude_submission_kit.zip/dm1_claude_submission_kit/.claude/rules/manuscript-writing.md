# Manuscript writing rule

## Structure

Each Results subsection should follow:

1. scientific question;
2. cohort and analysis;
3. primary quantitative result;
4. robustness or negative result;
5. restrained interpretation.

Each Discussion subsection should follow:

1. principal finding;
2. relationship to prior work;
3. plausible interpretation;
4. competing explanation;
5. boundary of inference;
6. concrete next validation step.

## Terminology

- Define DM1 and DM2 once, then use the same labels consistently.
- Prefer “state” over “subtype” unless stability and classification rules justify subtype.
- Prefer “lineage-low” and “iodine-handling-low” over an unqualified “RAI-resistant.”
- Use “patients” only when the unit is patients; use “samples” or “tumors” otherwise.
- Use “association,” “enrichment,” “concordance,” and “stratification” precisely.

## Style

- Remove repeated claims across abstract, Introduction, Results, and Discussion.
- Avoid stacked adjectives and promotional language.
- Use active voice when the actor is clear.
- Do not add literature citations merely to make prose look authoritative.
- Preserve author-approved voice sections.
- Do not change a technical statement during language polishing without logging the change.
