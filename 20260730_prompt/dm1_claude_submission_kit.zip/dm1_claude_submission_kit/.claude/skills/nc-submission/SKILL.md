---
name: nc-submission
description: Orchestrate evidence-locked repair and final scientific editing of the DM1 manuscript for Nature Communications. Use with audit, repair, or final as an argument.
disable-model-invocation: true
---

Mode: `$ARGUMENTS`

Accepted modes:

- `audit`: invoke the manuscript-audit workflow and stop.
- `repair`: repair the manuscript using the latest completed audit.
- `final`: run a post-repair red-team and make only evidence-supported final corrections.

If no mode is given, ask the user to choose. Do not assume `repair`.

# Repair mode

## Gate 1 — Preconditions

- Locate the newest complete `review_runs` audit.
- Confirm the branch and working-tree status.
- Refuse to edit if no claim ledger, statistical audit, clinical audit, figure audit, citation audit, and reproducibility audit exist.
- Read author voice approvals. Leave unapproved protected slots visibly marked.

## Gate 2 — Repair plan

The `managing-editor` must produce a ranked plan. Present the plan before editing when any proposed change would alter:

- title;
- central claim;
- figure architecture;
- endpoint interpretation;
- state labels;
- deletion of a main result.

## Gate 3 — Controlled edit passes

Perform passes in this order:

1. **Scientific truth pass** — remove contradictions and unsupported claims.
2. **Statistical direction pass** — unify endpoints, reference groups, n, effects, CIs, and p-values.
3. **Clinical restraint pass** — correct RAI, predictive, clinical-utility, and IHC language.
4. **Narrative architecture pass** — one central story, no repeated result paragraphs.
5. **Figure/caption pass** — synchronize figures and text.
6. **Methods/reproducibility pass** — sufficient detail and exact source mapping.
7. **Citation pass** — support and attribution.
8. **Language pass** — clarity and concision only after truth is locked.
9. **Submission metadata pass** — availability, contributions, conflicts, funding, affiliations, placeholders.

For every changed quantitative or clinical sentence, write an entry to `08_change_log.md`:

`file | location | old | new | reason | evidence | reviewer issue`

## Gate 4 — Cross-file consistency

Search all manuscript and submission files for:

- every audit-locked number;
- DM1/DM2 definitions;
- “predict,” “predictive,” “validation,” “causal,” “mechanism,” “RAI-resistant,” “actionable,” “pending,” and “prospective”;
- figure and supplementary numbering;
- placeholders such as TBD, XXX, TODO, `<...>`, local paths, and unfilled URLs.

Resolve or list each occurrence.

## Gate 5 — Independent post-edit review

Run `statistical-reviewer` and `clinical-reviewer` again on the repaired draft without showing them the change log. Then run `hostile-reviewer`.

The managing editor may repair only issues supported by evidence. Do not respond to hostile comments by inventing new analyses or claims.

# Final mode

- Verify no critical blockers remain.
- Re-run claim-ledger consistency.
- Re-run figure manifest consistency.
- Confirm author approval of protected sections.
- Confirm Data and Code Availability contain stable, real locations or clearly list them as administrative blockers.
- Produce `FINAL_EDITORIAL_DECISION.md` with one verdict:
  - `NOT READY`
  - `READY AFTER AUTHOR/ADMIN INPUT`
  - `SUBMISSION-READY`

Never label the package submission-ready while a central result direction, source data, author voice, or repository DOI is unresolved.
