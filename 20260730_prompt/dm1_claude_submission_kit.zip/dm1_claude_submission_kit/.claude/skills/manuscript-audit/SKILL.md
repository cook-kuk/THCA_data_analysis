---
name: manuscript-audit
description: Run a read-first, multi-agent audit of the DM1 manuscript, analyses, figures, citations, and reproducibility before any repair.
disable-model-invocation: true
---

Run a complete audit without editing the canonical manuscript or analysis outputs.

## Step 1 — Establish state

- Confirm repository root and current git branch.
- Record HEAD, dirty files, and available manuscript files.
- Create `manuscript_v8/review_runs/<YYYYMMDD_HHMMSS>/`.
- Write `00_inventory.md` with file paths, sizes, modification times, and identified canonical versions.
- Read all `manuscript_v8/SUBMISSION_CONTROL/*.md` files.

## Step 2 — Build claim ledger

Extract all quantitative and clinically consequential claims from:

- title;
- abstract;
- Introduction final paragraph;
- Results;
- figure captions;
- Discussion;
- Methods;
- cover letter;
- reviewer Q&A.

Write `01_claim_evidence_ledger.tsv` with:

`claim_id, location, exact_claim, cohort, endpoint, n, effect, ci, p, model, reference_direction, evidence_file, evidence_locator, status, action`

Use `VERIFIED`, `CONFLICT`, `MISSING SOURCE`, `DIRECTION UNKNOWN`, or `OVERCLAIM`.

## Step 3 — Delegate independent reviews

Run these agents independently, preferably in parallel:

- `statistical-reviewer`
- `clinical-reviewer`
- `reproducibility-auditor`
- `figure-editor` in audit-only mode
- `citation-auditor`

Save their reports as `02_...` through `06_...` in the review-run directory.

Do not allow one reviewer to see another reviewer’s conclusions before writing its own report.

## Step 4 — Consolidate

Create `BLOCKERS.md` with de-duplicated issues grouped as:

- fatal scientific;
- major scientific;
- manuscript consistency;
- figures and source data;
- reproducibility;
- journal compliance;
- author input;
- submission administration.

Create `09_submission_readiness.md` with a 0–2 score for:

- central claim validity;
- statistical validity;
- clinical restraint;
- external validation;
- figures;
- Methods;
- reproducibility;
- citations;
- journal formatting;
- administrative completeness.

Scoring:

- 0 = not ready;
- 1 = repairable;
- 2 = submission-ready.

## Stop condition

Stop after the audit. Do not repair files unless the user separately invokes `/nc-submission repair`.
