---
name: voice-interview
description: Interview Seungho Cook for the six protected author-voice sections and produce approval-ready drafts without inventing motivation or interpretation.
disable-model-invocation: true
---

Read `manuscript_v8/SUBMISSION_CONTROL/VOICE_PROTECTED_SLOTS.md` and locate the corresponding slots in the current manuscript files.

## Interaction rule

Do not ask all questions at once. Start with V1 and V2 and ask no more than three focused questions. Wait for the author’s response. Accept Korean fragments.

For each slot:

1. show the current surrounding text;
2. state the factual ingredients that are already verified;
3. identify what only the author can decide;
4. ask focused questions;
5. after the author responds, draft:
   - restrained Nature-style version;
   - direct authorial version;
6. list substantive phrases added by Claude;
7. ask for approval before inserting.

## Prohibitions

- Do not fabricate a patient story, clinical observation, or personal motivation.
- Do not intensify certainty.
- Do not use emotional language that the author did not supply.
- Do not hide limitations from the opening or aim.
- Do not finalize Reviewer Q9 without explicit author position.

## Deliverable

Maintain `manuscript_v8/SUBMISSION_CONTROL/AUTHOR_VOICE_APPROVAL.md` with:

`slot | author raw input | polished draft | author-approved? | approval date | inserted file/location`
