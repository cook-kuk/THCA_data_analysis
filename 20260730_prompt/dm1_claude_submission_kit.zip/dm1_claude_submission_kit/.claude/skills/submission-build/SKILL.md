---
name: submission-build
description: Build and validate a local Nature Communications submission package for the DM1 manuscript without uploading or publishing anything.
disable-model-invocation: true
---

Build only after the latest `FINAL_EDITORIAL_DECISION.md` is `SUBMISSION-READY` or the user explicitly accepts listed administrative blockers.

## Create package

Create:

```text
submission/Nature_Communications_DM1_<YYYYMMDD>/
├── Main_Manuscript.<docx|tex|pdf|md>
├── Cover_Letter.<docx|pdf|md>
├── Figures/
│   ├── Figure_1.<pdf|tif|png>
│   └── ...
├── Supplementary_Information.<docx|pdf>
├── Supplementary_Data/
├── Source_Data_Manifest.tsv
├── Code_and_Data_Availability.md
├── Author_and_Affiliation_Check.md
├── Reporting_Summary_COMPLETION_GUIDE.md
├── Editorial_Policy_Checklist_COMPLETION_GUIDE.md
└── SUBMISSION_README.md
```

Use actual available conversion tools. If DOCX/PDF conversion cannot be produced reproducibly, keep the source MD/TeX and record the blocker. Do not claim that a file was built when it was not.

## Validation checks

- all files open successfully;
- manuscript figures are cited in order;
- all supplementary items are cited;
- all figure captions match filenames and panels;
- all source data files exist;
- no broken links or local absolute paths;
- no placeholders;
- title and author list agree across files;
- corresponding-author email is present;
- affiliations include institution, city, and country;
- Data Availability and Code Availability are separate and accurate;
- author contributions, competing interests, funding, and sponsor role are present;
- reporting-summary guide is consistent with Methods;
- package size and formats are recorded.

## Human-only actions

List but do not perform:

- corresponding-author approval;
- all-author approval and order confirmation;
- ORCID profile checks;
- final affiliation confirmation;
- reporting-summary smart-PDF completion;
- editorial-policy checklist completion;
- Zenodo release/public repository publication;
- manuscript portal upload;
- suggested/excluded reviewer entry;
- license and payment selections.

## Final output

Write `SUBMISSION_README.md` with:

- package contents;
- canonical manuscript version and git commit;
- build command and date;
- remaining human actions;
- known limitations;
- explicit statement that no external upload occurred.
