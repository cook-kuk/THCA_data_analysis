---
name: figure-lock
description: Audit and lock the DM1 figure architecture, panel numbering, statistics, captions, and source-data mapping before manuscript finalization.
disable-model-invocation: true
---

Create or update a timestamped review run. Do not change scientific values.

## Phase A — Inventory

Find all main and supplementary figure assets, scripts, captions, and manuscript citations. Include files under `figures/`, web public assets, analysis output folders, and manuscript references.

Create `FIGURE_MANIFEST.tsv` with:

`figure, panel, proposed_title, purpose, cohort, n, source_data, script, output_file, statistic, caption_file, cited_in_text, status`

## Phase B — Resolve architecture

Compare:

- the reviewer-first five-figure design;
- the latest v2 manuscript structure;
- current available assets.

Propose two coherent options:

1. a compact five-main-figure narrative;
2. a multi-figure narrative within current journal expectations.

For each option, explain trade-offs in legibility, redundancy, clinical emphasis, and reviewer risk. Recommend one, but do not renumber canonical files until the author or managing editor chooses.

## Phase C — Missing panels

For Fig. 3C and Fig. 3D:

- locate paired inputs and existing analysis code;
- verify sample matching and values;
- prepare an executable generation plan;
- generate panels only when all definitions are known;
- record commands and output hashes.

For the ATA mosaic:

- proceed only if ATA 2015 tier mapping, denominators, missingness, and state labels are recoverable;
- otherwise recommend removal or Supplementary placement.

## Phase D — Caption lock

Ensure each caption includes:

- brief whole-figure title;
- panel-by-panel description;
- cohort and exact n;
- unit of analysis;
- test, sidedness, adjustment, and effect definition;
- error-bar definition;
- abbreviations;
- source-data availability.

## Deliverable

Write `FIGURE_LOCK_REPORT.md` and assign every panel:

- `LOCKED`
- `REBUILD REQUIRED`
- `SOURCE MISSING`
- `MOVE TO SUPPLEMENT`
- `REMOVE`
- `EDITORIAL DECISION REQUIRED`
